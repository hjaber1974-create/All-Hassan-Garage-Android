package com.hassansourcing.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        // Keep an always-current internal Excel copy.
        runCatching { buildLatestExcel() }
        setContent { MaterialTheme { HassanSourcingApp() } }
    }

    private fun newPhotoFile(prefix: String): Pair<File, Uri> {
        val dir = File(filesDir, "photos").apply { mkdirs() }
        val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
        return file to FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun buildLatestExcel(): File {
        val dir = File(filesDir, "exports").apply { mkdirs() }
        val file = File(dir, "Hassan_Sourcing_Latest.xlsx")
        file.outputStream().use { out ->
            XlsxExporter.write(out, db.getSuppliers(), db.getProducts())
        }
        return file
    }

    private fun syncPreviouslySavedExcel(): Boolean {
        val saved = getSharedPreferences("prefs", MODE_PRIVATE).getString("last_export_uri", null)
        if (saved.isNullOrBlank()) return false
        return runCatching {
            val uri = Uri.parse(saved)
            contentResolver.openOutputStream(uri, "wt")?.use { out ->
                XlsxExporter.write(out, db.getSuppliers(), db.getProducts())
            } ?: error("Cannot open saved Excel")
            true
        }.getOrDefault(false)
    }

    private fun refreshExcelCopies() {
        runCatching { buildLatestExcel() }
        syncPreviouslySavedExcel()
    }

    @Composable
    private fun HassanSourcingApp() {
        var screen by remember { mutableStateOf("home") }
        var refresh by remember { mutableIntStateOf(0) }
        var selectedSupplierId by remember { mutableLongStateOf(-1L) }
        val suppliers = remember(refresh) { db.getSuppliers() }
        val products = remember(refresh) { db.getProducts() }

        val exportLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        ) { uri ->
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { out ->
                        XlsxExporter.write(out, db.getSuppliers(), db.getProducts())
                    } ?: error("Cannot open file")
                    try {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                    } catch (_: Exception) { }
                    getSharedPreferences("prefs", MODE_PRIVATE)
                        .edit().putString("last_export_uri", uri.toString()).apply()
                    runCatching { buildLatestExcel() }
                    toast("Excel saved with ${db.getProducts().size} items / تم حفظ ${db.getProducts().size} منتج")
                } catch (e: Exception) {
                    toast("Save failed: ${e.message}")
                }
            }
        }

        fun shareLatestExcel() {
            try {
                val file = buildLatestExcel()
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, "Share latest Excel / مشاركة أحدث Excel"))
            } catch (e: Exception) {
                toast("Share failed: ${e.message}")
            }
        }

        when (screen) {
            "supplier" -> SupplierForm(
                onBack = { screen = "home" },
                onSaved = { id ->
                    refreshExcelCopies()
                    refresh++
                    selectedSupplierId = id
                    screen = "detail"
                }
            )
            "product" -> ProductForm(
                suppliers = suppliers,
                preferredSupplierId = selectedSupplierId,
                onBack = { screen = if (selectedSupplierId > 0) "detail" else "home" },
                onSaved = { supplierId ->
                    refreshExcelCopies()
                    refresh++
                    selectedSupplierId = supplierId
                    screen = "detail"
                }
            )
            "list" -> DataList(
                suppliers = suppliers,
                products = products,
                onBack = { screen = "home" },
                onSupplier = { id -> selectedSupplierId = id; screen = "detail" }
            )
            "detail" -> {
                val supplier = suppliers.firstOrNull { it.id == selectedSupplierId }
                if (supplier == null) {
                    LaunchedEffect(Unit) { screen = "home" }
                } else {
                    SupplierDetail(
                        supplier = supplier,
                        products = products.filter { it.supplierId == supplier.id },
                        onHome = { screen = "home" },
                        onAddItem = { screen = "product" },
                        onSaveExcel = {
                            val name = "Hassan_Sourcing_${SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())}.xlsx"
                            exportLauncher.launch(name)
                        },
                        onShare = { shareLatestExcel() }
                    )
                }
            }
            else -> HomeScreen(
                supplierCount = suppliers.size,
                productCount = products.size,
                onNewSupplier = { screen = "supplier" },
                onAddProduct = {
                    selectedSupplierId = suppliers.firstOrNull()?.id ?: -1L
                    screen = "product"
                },
                onView = { screen = "list" },
                onExport = {
                    val name = "Hassan_Sourcing_${SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())}.xlsx"
                    exportLauncher.launch(name)
                },
                onShare = { shareLatestExcel() }
            )
        }
    }

    @Composable
    private fun HomeScreen(
        supplierCount: Int,
        productCount: Int,
        onNewSupplier: () -> Unit,
        onAddProduct: () -> Unit,
        onView: () -> Unit,
        onExport: () -> Unit,
        onShare: () -> Unit
    ) {
        Scaffold(topBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Hassan Sourcing", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Offline Supplier & Item Manager")
                    }
                    Text("V3")
                }
            }
        }) { pad ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceAround) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$supplierCount", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                Text("Suppliers / موردين")
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$productCount", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                Text("Items / منتجات")
                            }
                        }
                    }
                }
                item { BigButton("+ New Supplier / مورد جديد", onNewSupplier) }
                item { BigButton("+ Add Item / إضافة منتج", onAddProduct) }
                item { BigButton("Suppliers & Items / عرض البيانات", onView) }
                item { BigButton("Save Excel (.xlsx) / حفظ Excel", onExport) }
                item { BigButton("Share Latest Excel / مشاركة أحدث Excel", onShare) }
                item {
                    OutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Excel Auto Update ✓", fontWeight = FontWeight.Bold)
                            Text("Every saved item is written to the latest Excel automatically.")
                            Text("كل منتج تحفظه يتسجل فوراً في أحدث ملف Excel.")
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun BigButton(text: String, action: () -> Unit) {
        Button(onClick = action, modifier = Modifier.fillMaxWidth().height(58.dp)) { Text(text) }
    }

    @Composable
    private fun SupplierForm(onBack: () -> Unit, onSaved: (Long) -> Unit) {
        var name by remember { mutableStateOf("") }
        var contact by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var whatsapp by remember { mutableStateOf("") }
        var wechat by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var address by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        var cardPath by remember { mutableStateOf("") }
        var pendingFile by remember { mutableStateOf<File?>(null) }
        var saving by remember { mutableStateOf(false) }

        val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) cardPath = pendingFile?.absolutePath ?: ""
        }

        FormScaffold("New Supplier / مورد جديد", onBack) {
            item {
                Button(onClick = {
                    val (file, uri) = newPhotoFile("business_card")
                    pendingFile = file
                    camera.launch(uri)
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (cardPath.isBlank()) "Take Business Card Photo / صوّر الكرت" else "✓ Business card saved / تم حفظ صورة الكرت")
                }
            }
            item { Field("Company / اسم الشركة *", name) { name = it } }
            item { Field("Contact person / اسم الشخص", contact) { contact = it } }
            item { Field("Phone / تلفون", phone) { phone = it } }
            item { Field("WhatsApp", whatsapp) { whatsapp = it } }
            item { Field("WeChat", wechat) { wechat = it } }
            item { Field("Email", email) { email = it } }
            item { Field("Address / العنوان", address) { address = it } }
            item { Field("Notes / ملاحظات", notes, minLines = 3) { notes = it } }
            item {
                Button(
                    enabled = !saving,
                    onClick = {
                        if (name.isBlank()) toast("Company name required / اكتب اسم الشركة")
                        else runCatching {
                            saving = true
                            db.addSupplier(name, contact, phone, whatsapp, wechat, email, address, notes, cardPath)
                        }.onSuccess { id ->
                            toast("Saved ✓ / تم الحفظ")
                            onSaved(id)
                        }.onFailure { e ->
                            saving = false
                            toast("Save failed: ${e.message}")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text("SAVE SUPPLIER / حفظ المورد") }
            }
        }
    }

    @Composable
    private fun ProductForm(
        suppliers: List<Supplier>,
        preferredSupplierId: Long,
        onBack: () -> Unit,
        onSaved: (Long) -> Unit
    ) {
        if (suppliers.isEmpty()) {
            FormScaffold("Add Item / إضافة منتج", onBack) {
                item { Text("Add a supplier first. / لازم تضيف مورد أولاً.") }
            }
            return
        }

        var selected by remember {
            mutableStateOf(suppliers.firstOrNull { it.id == preferredSupplierId } ?: suppliers.first())
        }
        var menu by remember { mutableStateOf(false) }
        var name by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var currency by remember { mutableStateOf("RMB") }
        var moq by remember { mutableStateOf("") }
        var cartonQty by remember { mutableStateOf("") }
        var cartonSize by remember { mutableStateOf("") }
        var weight by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        var photoPath by remember { mutableStateOf("") }
        var pendingFile by remember { mutableStateOf<File?>(null) }
        var saving by remember { mutableStateOf(false) }

        val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoPath = pendingFile?.absolutePath ?: ""
        }

        FormScaffold("Add Item / إضافة منتج", onBack) {
            item {
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Supplier / المورد: ${selected.name}")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        suppliers.forEach { s ->
                            DropdownMenuItem(text = { Text(s.name) }, onClick = { selected = s; menu = false })
                        }
                    }
                }
            }
            item {
                Button(onClick = {
                    val (file, uri) = newPhotoFile("product")
                    pendingFile = file
                    camera.launch(uri)
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (photoPath.isBlank()) "Take Item Photo / صوّر المنتج" else "✓ Item photo saved / تم حفظ الصورة")
                }
            }
            item { Field("Item name / اسم المنتج *", name) { name = it } }
            item { Field("Price / السعر", price) { price = it } }
            item { Field("Currency (RMB / USD) / العملة", currency) { currency = it } }
            item { Field("MOQ / أقل كمية", moq) { moq = it } }
            item { Field("Qty per carton / عدد بالكرتونة", cartonQty) { cartonQty = it } }
            item { Field("Carton size CBM or L×W×H / حجم الكرتونة", cartonSize) { cartonSize = it } }
            item { Field("Weight / الوزن", weight) { weight = it } }
            item { Field("Notes / ملاحظات", notes, minLines = 3) { notes = it } }
            item {
                Button(
                    enabled = !saving,
                    onClick = {
                        if (name.isBlank()) toast("Item name required / اكتب اسم المنتج")
                        else runCatching {
                            saving = true
                            db.addProduct(selected.id, name, price, currency, moq, cartonQty, cartonSize, weight, notes, photoPath)
                        }.onSuccess {
                            toast("Item added ✓ / تمت إضافة المنتج")
                            onSaved(selected.id)
                        }.onFailure { e ->
                            saving = false
                            toast("Save failed: ${e.message}")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text("ADD ITEM / إضافة المنتج") }
            }
        }
    }

    @Composable
    private fun SupplierDetail(
        supplier: Supplier,
        products: List<Product>,
        onHome: () -> Unit,
        onAddItem: () -> Unit,
        onSaveExcel: () -> Unit,
        onShare: () -> Unit
    ) {
        Scaffold(topBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onHome) { Text("← Home / الرئيسية") }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(supplier.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${products.size} items / ${products.size} منتجات")
                }
            }
        }) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Saved ✓ / تم الحفظ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            if (supplier.contact.isNotBlank()) Text("Contact: ${supplier.contact}")
                            if (supplier.whatsapp.isNotBlank()) Text("WhatsApp: ${supplier.whatsapp}")
                        }
                    }
                }
                if (products.isEmpty()) {
                    item { Text("No items yet / لا يوجد منتجات بعد") }
                } else {
                    items(products) { p -> ProductCard(p) }
                }
                item { BigButton("+ Add Another Item / إضافة منتج آخر", onAddItem) }
                item { BigButton("Save Excel Now / حفظ Excel الآن", onSaveExcel) }
                item { OutlinedButton(onClick = onShare, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("Share Latest Excel / مشاركة أحدث Excel") } }
            }
        }
    }

    @Composable
    private fun ProductCard(p: Product) {
        OutlinedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                if (p.price.isNotBlank()) Text("${p.price} ${p.currency}")
                if (p.moq.isNotBlank()) Text("MOQ: ${p.moq}")
                if (p.cartonQty.isNotBlank()) Text("Carton qty: ${p.cartonQty}")
                if (p.cartonSize.isNotBlank()) Text("Carton size: ${p.cartonSize}")
                if (p.weight.isNotBlank()) Text("Weight: ${p.weight}")
                if (p.notes.isNotBlank()) Text(p.notes)
            }
        }
    }

    @Composable
    private fun FormScaffold(title: String, onBack: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
        Scaffold(topBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back / رجوع") }
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        }
    }

    @Composable
    private fun Field(label: String, value: String, minLines: Int = 1, onChange: (String) -> Unit) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
            minLines = minLines,
            singleLine = minLines == 1
        )
    }

    @Composable
    private fun DataList(
        suppliers: List<Supplier>,
        products: List<Product>,
        onBack: () -> Unit,
        onSupplier: (Long) -> Unit
    ) {
        Scaffold(topBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back / رجوع") }
                Text("Suppliers & Items", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(suppliers) { s ->
                    Card(Modifier.fillMaxWidth().clickable { onSupplier(s.id) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            if (s.contact.isNotBlank()) Text("Contact: ${s.contact}")
                            if (s.whatsapp.isNotBlank()) Text("WhatsApp: ${s.whatsapp}")
                            val ps = products.filter { it.supplierId == s.id }
                            Text("Items: ${ps.size} / المنتجات: ${ps.size}", fontWeight = FontWeight.SemiBold)
                            ps.take(3).forEach { p ->
                                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                                Text(p.name)
                            }
                            if (ps.size > 3) Text("+ ${ps.size - 3} more...")
                        }
                    }
                }
            }
        }
    }
}
