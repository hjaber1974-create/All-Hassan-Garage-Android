package com.hassansourcing.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Supplier(
    val id: Long,
    val name: String,
    val contact: String,
    val phone: String,
    val whatsapp: String,
    val wechat: String,
    val email: String,
    val address: String,
    val notes: String,
    val businessCardPath: String
)

data class Product(
    val id: Long,
    val supplierId: Long,
    val name: String,
    val price: String,
    val currency: String,
    val moq: String,
    val cartonQty: String,
    val cartonSize: String,
    val weight: String,
    val notes: String,
    val photoPath: String
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "hassan_sourcing.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE suppliers(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                contact TEXT,
                phone TEXT,
                whatsapp TEXT,
                wechat TEXT,
                email TEXT,
                address TEXT,
                notes TEXT,
                businessCardPath TEXT
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE products(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplierId INTEGER NOT NULL,
                name TEXT NOT NULL,
                price TEXT,
                currency TEXT,
                moq TEXT,
                cartonQty TEXT,
                cartonSize TEXT,
                weight TEXT,
                notes TEXT,
                photoPath TEXT,
                FOREIGN KEY(supplierId) REFERENCES suppliers(id)
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun addSupplier(
        name: String, contact: String, phone: String, whatsapp: String, wechat: String,
        email: String, address: String, notes: String, businessCardPath: String
    ): Long {
        val values = ContentValues().apply {
            put("name", name.trim())
            put("contact", contact.trim())
            put("phone", phone.trim())
            put("whatsapp", whatsapp.trim())
            put("wechat", wechat.trim())
            put("email", email.trim())
            put("address", address.trim())
            put("notes", notes.trim())
            put("businessCardPath", businessCardPath)
        }
        return writableDatabase.insertOrThrow("suppliers", null, values)
    }

    fun addProduct(
        supplierId: Long, name: String, price: String, currency: String, moq: String,
        cartonQty: String, cartonSize: String, weight: String, notes: String, photoPath: String
    ): Long {
        val values = ContentValues().apply {
            put("supplierId", supplierId)
            put("name", name.trim())
            put("price", price.trim())
            put("currency", currency.trim())
            put("moq", moq.trim())
            put("cartonQty", cartonQty.trim())
            put("cartonSize", cartonSize.trim())
            put("weight", weight.trim())
            put("notes", notes.trim())
            put("photoPath", photoPath)
        }
        return writableDatabase.insertOrThrow("products", null, values)
    }

    fun getSuppliers(): List<Supplier> {
        val result = mutableListOf<Supplier>()
        readableDatabase.rawQuery("SELECT * FROM suppliers ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) {
                result += Supplier(
                    c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("contact")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("phone")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("whatsapp")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("wechat")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("email")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("address")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("notes")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("businessCardPath")) ?: ""
                )
            }
        }
        return result
    }

    fun getProducts(): List<Product> {
        val result = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) {
                result += Product(
                    c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getLong(c.getColumnIndexOrThrow("supplierId")),
                    c.getString(c.getColumnIndexOrThrow("name")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("price")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("currency")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("moq")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("cartonQty")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("cartonSize")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("weight")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("notes")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("photoPath")) ?: ""
                )
            }
        }
        return result
    }
}
