package com.hassansourcing.app

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object XlsxExporter {
    private fun esc(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun colName(index: Int): String {
        var n = index + 1
        val b = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            b.insert(0, ('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return b.toString()
    }

    private fun sheetXml(rows: List<List<String>>): String {
        val maxCols = rows.maxOfOrNull { it.size } ?: 1
        val sheetRows = buildString {
            rows.forEachIndexed { r, row ->
                val rowNum = r + 1
                append("<row r=\"$rowNum\">")
                row.forEachIndexed { c, v ->
                    val ref = "${colName(c)}$rowNum"
                    val style = if (r == 0) " s=\"1\"" else ""
                    append("<c r=\"$ref\" t=\"inlineStr\"$style><is><t xml:space=\"preserve\">${esc(v)}</t></is></c>")
                }
                append("</row>")
            }
        }
        val lastCol = colName(maxCols - 1)
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<cols><col min="1" max="$maxCols" width="22" customWidth="1"/></cols>
<sheetData>$sheetRows</sheetData>
<autoFilter ref="A1:${lastCol}1"/>
</worksheet>"""
    }

    fun write(output: OutputStream, suppliers: List<Supplier>, products: List<Product>) {
        val supplierHeaders = listOf(
            "Supplier ID", "Supplier", "Contact", "Phone", "WhatsApp", "WeChat",
            "Email", "Address", "Business Card Photo", "Supplier Notes", "Item Count"
        )
        val supplierRows = mutableListOf<List<String>>()
        supplierRows += supplierHeaders
        suppliers.forEach { s ->
            supplierRows += listOf(
                s.id.toString(), s.name, s.contact, s.phone, s.whatsapp, s.wechat,
                s.email, s.address, s.businessCardPath, s.notes,
                products.count { it.supplierId == s.id }.toString()
            )
        }

        val itemHeaders = listOf(
            "Item ID", "Supplier", "Contact", "Phone", "WhatsApp", "Item",
            "Price", "Currency", "MOQ", "Carton Qty", "Carton Size", "Weight",
            "Product Photo", "Item Notes", "Supplier Notes"
        )
        val itemRows = mutableListOf<List<String>>()
        itemRows += itemHeaders
        products.sortedBy { it.id }.forEach { p ->
            val s = suppliers.firstOrNull { it.id == p.supplierId }
            itemRows += listOf(
                p.id.toString(), s?.name.orEmpty(), s?.contact.orEmpty(), s?.phone.orEmpty(), s?.whatsapp.orEmpty(),
                p.name, p.price, p.currency, p.moq, p.cartonQty, p.cartonSize, p.weight,
                p.photoPath, p.notes, s?.notes.orEmpty()
            )
        }

        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

        val rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

        val workbook = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>
<sheet name="Suppliers" sheetId="1" r:id="rId1"/>
<sheet name="Items" sheetId="2" r:id="rId2"/>
</sheets>
</workbook>"""

        val workbookRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        val styles = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border/></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>
</styleSheet>"""

        ZipOutputStream(output).use { zip ->
            fun add(name: String, text: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(text.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            add("[Content_Types].xml", contentTypes)
            add("_rels/.rels", rels)
            add("xl/workbook.xml", workbook)
            add("xl/_rels/workbook.xml.rels", workbookRels)
            add("xl/styles.xml", styles)
            add("xl/worksheets/sheet1.xml", sheetXml(supplierRows))
            add("xl/worksheets/sheet2.xml", sheetXml(itemRows))
        }
    }
}
